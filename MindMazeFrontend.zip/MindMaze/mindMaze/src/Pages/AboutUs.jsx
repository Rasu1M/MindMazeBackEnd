import {Link} from "react-router-dom"

const AboutUs = ()=>{
    return (
    <>
    <h1>About US</h1>
    <Link to="/">Home</Link>
    </>
    )
}
export default AboutUs