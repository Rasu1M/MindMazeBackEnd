

const Medals = () => {
    return (
        <>
        <main>
            <h1>Medals</h1>
        </main>
        </>
    )
}

export default Medals