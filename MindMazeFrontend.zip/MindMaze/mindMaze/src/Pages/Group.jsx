const Group = () => {
  return (
    <>
      <main>
        <h1>Group</h1>
      </main>
    </>
  );
};

export default Group;
