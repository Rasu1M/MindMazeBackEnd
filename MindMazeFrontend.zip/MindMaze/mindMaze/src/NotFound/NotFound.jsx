import {Link} from "react-router-dom"
const NotFound =()=>{
    return (
        <>
            <h1>Page don't found</h1>
            <Link to='/gamer-modes'>Home</Link>
        </>
    )
}
export default NotFound