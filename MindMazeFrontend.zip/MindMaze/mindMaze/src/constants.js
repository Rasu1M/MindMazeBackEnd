export const resultInitialState = {
  score:0,
  correctAnswers:0,
  wrongAnswers: 0
};
